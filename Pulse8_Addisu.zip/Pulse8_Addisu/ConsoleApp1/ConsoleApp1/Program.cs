﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //set the connection string
            string connString = @"Server =PEACE\ETHIOPIA; Database = Pulse8TestDB; Trusted_Connection = True;";

            //variables to store the query results
            int memberID, DiagnosisID, DiagnosisCategoryID, CategoryScore, IsMostSevereCategory;
            string FirstName, LastName, DiagnosisDescription, CategoryDescription;

            try
            {
                //sql connection object
                using (SqlConnection conn = new SqlConnection(connString))
                {

                    //set stored procedure name
                    string spName = @"dbo.[usp_getmembersInfo]";

                    //define the SqlCommand object
                    SqlCommand cmd = new SqlCommand(spName, conn);
                    Console.WriteLine("Enter the memberID: ");
                    //Set SqlParameter - the memeber id parameter value will be set from the command line
                    SqlParameter param1 = new SqlParameter();
                    param1.ParameterName = "@memberid";
                    param1.SqlDbType = SqlDbType.Int;
                    param1.Value = Convert.ToInt32(Console.ReadLine());
                   // param1.Value = int.Parse(args[0].ToString());

                    //add the parameter to the SqlCommand object
                    cmd.Parameters.Add(param1);

                    //open connection
                    conn.Open();

                    //set the SqlCommand type to stored procedure and execute
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataReader dr = cmd.ExecuteReader();

                    Console.WriteLine(Environment.NewLine + "Retrieving data from database..." + Environment.NewLine);
                    Console.WriteLine("Retrieved records:");
                    Console.WriteLine("[Member ID] | [First Name]  | [Last Name] | [Most Severe Diagnosis ID]  | [Most Severe Diagnosis Description]  | [Category ID]  | [Category Description]  |  [Category Score]  |  [Is Most Severe Category]");

                    //check if there are records
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            memberID = dr.GetInt32(0);
                            FirstName = dr.GetString(1);
                            LastName = dr.GetString(2);
                            DiagnosisID = dr.GetInt32(3);
                            DiagnosisDescription = dr.GetString(4);
                            DiagnosisCategoryID = dr.GetInt32(5);
                            CategoryDescription = dr.GetString(6);
                            CategoryScore = dr.GetInt32(7);
                            IsMostSevereCategory = dr.GetInt32(8);
                           
                            //display retrieved record
                            Console.WriteLine(String.Format("{0} \t | {1}\t | {2}\t | {3}\t |  {4}\t | {5}\t | {6}\t |  {7} \t | {8}", memberID.ToString(), FirstName, LastName, DiagnosisID.ToString(), DiagnosisDescription, DiagnosisCategoryID.ToString(), CategoryDescription, CategoryScore.ToString(), IsMostSevereCategory.ToString()));

                        }
                    }
                    else
                    {
                        Console.WriteLine("No data found.");
                    }

                    //close data reader
                    dr.Close();

                    //close connection
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                //display error message
                Console.WriteLine("Exception: " + ex.Message);
            }

        }
    }
}
