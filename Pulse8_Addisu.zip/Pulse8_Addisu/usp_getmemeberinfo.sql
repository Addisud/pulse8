CREATE PROCEDURE usp_getmembersInfo @memberid int
as
Select m.MemberID as [Member ID],
       m.FirstName as [First Name],
	   m.LastName as [Last Name],
	   isnull(a.DiagnosisID, 0) as [Most Severe Diagnosis ID],
	   isnull(d.DiagnosisDescription,'N/A') as [Most Severe Diagnosis Description],
       isnull(dc.DiagnosisCategoryID, 0) as [Category ID],
	   isnull(dc.CategoryDescription,'N/A') as [Category Description],
	   isnull(dc.CategoryScore,'0') as [Category Score],
	   Case when (Rank() Over (Partition by m.memberid order by dc.DiagnosisCategoryID) = 1)  then 1
	         else 0 
		end as [Is Most Severe Category]
from Member as m left join
							(Select m.MemberID, min(md.DiagnosisID) as DiagnosisID
							from Member as m left join MemberDiagnosis as md ON m.MemberID = md.MemberID
							group by m.MemberID
							)
							 as a on m.MemberID = a.MemberID
				 left join  Diagnosis as d ON d.DiagnosisID = a.DiagnosisID
				 left join DiagnosisCategoryMap as dm on dm.DiagnosisID = d.DiagnosisID
				 left join DiagnosisCategory as dc on dc.DiagnosisCategoryID = dm.DiagnosisCategoryID
where m.MemberID = @memberid
